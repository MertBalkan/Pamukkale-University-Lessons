/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package hafta6;

/**
 *
 * @author Admin
 */
public class Arac {
    
    private String plaka;
    private String aracSahibi;
    
    public Arac(String plaka, String sahip) {
        this.plaka = plaka;
        this.aracSahibi = sahip;
    }
    
    public String getPlaka() {
        return this.plaka;
    }
    
    public String getAracSahibi(){
        return aracSahibi;
    }
}
