/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package hafta6;

/**
 *
 * @author Admin
 */
public class Otopark {
    
    private final int kapasite;
    private int ucret;
    private Arac[] araclar;
    private int toplamKazanc;
    
    public Otopark(int kapasite, int ucret) {
        this.kapasite = kapasite;
        this.ucret = ucret;
        this.toplamKazanc = 0;
        this.araclar = new Arac[kapasite];
    }
    
    public Otopark(Otopark otopark) {
        this.kapasite = otopark.kapasite;
        this.ucret = otopark.ucret;
        this.araclar = otopark.araclar;
        this.toplamKazanc = otopark.toplamKazanc;
    }
    
    public void parkEt(Arac arac) {
        for (int i = 0; i < araclar.length; i++) {
            if(araclar[i] == null) {
                araclar[i] = arac;
                toplamKazanc+=ucret;
                break;
            }
        }
    }
    
    public void aracCikar(int aracIndex) {
        if (araclar[aracIndex]!= null) {
            Arac arac = araclar[aracIndex];
            System.out.println(arac.getPlaka() + " Plakalı araç çıkış yaptı...");
            araclar[aracIndex] = null;
        }
    }
    
    public void otoparkBilgi() {
        System.out.println("---------------------");
        System.out.println("Otopark Bilgisi : ");
        System.out.println("Toplam Kazanc : " + toplamKazanc);
        
        for(int i = 0; i<araclar.length;i++) {
            if(this.araclar[i] != null) {
                Arac arac = this.araclar[i];
                System.out.println("Plaka : "+arac.getPlaka() + " Arac Sahibi : "+ arac.getAracSahibi());
            }
        }
        
        System.out.println("---------------------");

    }
    
    
}
