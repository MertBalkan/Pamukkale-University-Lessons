/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package hafta6;

/**
 *
 * @author Admin
 */
public class OtoparkTest {
    
    public static void main (String[] Args) {
        Otopark otopark = new Otopark(20,10);
        
        
        Arac arac1 = new Arac("20 AZT 98","Ali Yılmaz");
        Arac arac2 = new Arac("20 BT 086","Veli Yılmaz");
        Arac arac3 = new Arac("09 AB 095","Mehmet Can");

        otopark.parkEt(arac1);
        otopark.parkEt(arac2);
        
        otopark.otoparkBilgi();
        
        otopark.aracCikar(1);
        
        otopark.parkEt(arac3);
        
        otopark.otoparkBilgi();
        
        Otopark otoparkYeni = new Otopark(otopark);
        Arac arac4 = new Arac("20 B 0869","Ali Can");
        otoparkYeni.parkEt(arac4);
        
        Otopark otopark1 = otopark; 
        
        
        
        otoparkYeni.otoparkBilgi();
        otopark.otoparkBilgi();
    }
    
}
