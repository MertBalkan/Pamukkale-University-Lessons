/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package hafta6;

import java.util.Random;

/**
 *
 * @author Admin
 */
public class Hafta6 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        int kapasite = 40;
        int[] notlar = new int[kapasite];
        
        Random rnd = new Random();
        
        for (int i=0;i<notlar.length; i++) {
            notlar[i] = rnd.nextInt(101);
        }
        
        int[] frekans = new int[11];
        
        for (int i = 0; i<notlar.length; i++) {
            int not = notlar[i];
            frekans[not/10]++;
        }
        
        int maxFrekans = 0;
        
        for(int i =0; i<frekans.length; i++) {
            if (frekans[i] > maxFrekans) {
                maxFrekans = frekans[i];
            }
        }
        
        
        for (int seviye = maxFrekans; seviye>0; seviye--) {
            for(int i = 0; i<frekans.length; i++) {
                if(seviye <= frekans[i]) {
                    System.out.print("   *   ");
                } else {
                    System.out.print("       ");
                }
            }
            System.out.println();
        }
        
        for (int i = 0; i<frekans.length; i++) {
            System.out.print(" ----- ");
        }
        
        System.out.println();
        
        for (int i=0; i<frekans.length-1;i++) {
            System.out.printf(" %02d-%02d ", i*10, (i+1)*10 - 1);
        }
        
        System.out.println("  100  ");
        
           
        
        
            
        
        
    }
}
